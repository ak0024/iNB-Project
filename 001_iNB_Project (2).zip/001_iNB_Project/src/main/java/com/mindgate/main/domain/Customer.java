package com.mindgate.main.domain;

import java.util.Objects;

public class Customer {
	private String firstName;
	private String lastName;
	private String userName;
	private String password;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String city;
	private String state;
	private Long zip;
	private Long phone;
	private Long cell;
	private String email;
	private String customerId;
	private String customerStatus;
	private String passwordReachLimit;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(String firstName, String lastName, String userName, String password, String addressLine1,
			String addressLine2, String addressLine3, String city, String state, Long zip, Long phone, Long cell,
			String email, String customerId, String customerStatus, String passwordReachLimit) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.phone = phone;
		this.cell = cell;
		this.email = email;
		this.customerId = customerId;
		this.customerStatus = customerStatus;
		this.passwordReachLimit = passwordReachLimit;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getZip() {
		return zip;
	}

	public void setZip(Long zip) {
		this.zip = zip;
	}

	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public Long getCell() {
		return cell;
	}

	public void setCell(Long cell) {
		this.cell = cell;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerStatus() {
		return customerStatus;
	}

	public void setCustomerStatus(String customerStatus) {
		this.customerStatus = customerStatus;
	}

	public String getPasswordReachLimit() {
		return passwordReachLimit;
	}

	public void setPasswordReachLimit(String passwordReachLimit) {
		this.passwordReachLimit = passwordReachLimit;
	}

	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", userName=" + userName + ", password="
				+ password + ", addressLine1=" + addressLine1 + ", addressLine2=" + addressLine2 + ", addressLine3="
				+ addressLine3 + ", city=" + city + ", state=" + state + ", zip=" + zip + ", phone=" + phone + ", cell="
				+ cell + ", email=" + email + ", customerId=" + customerId + ", customerStatus=" + customerStatus
				+ ", passwordReachLimit=" + passwordReachLimit + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(addressLine1, addressLine2, addressLine3, cell, city, customerId, customerStatus, email,
				firstName, lastName, password, passwordReachLimit, phone, state, userName, zip);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(addressLine1, other.addressLine1) && Objects.equals(addressLine2, other.addressLine2)
				&& Objects.equals(addressLine3, other.addressLine3) && cell == other.cell
				&& Objects.equals(city, other.city) && Objects.equals(customerId, other.customerId)
				&& Objects.equals(customerStatus, other.customerStatus) && Objects.equals(email, other.email)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(password, other.password)
				&& Objects.equals(passwordReachLimit, other.passwordReachLimit) && phone == other.phone
				&& Objects.equals(state, other.state) && Objects.equals(userName, other.userName) && zip == other.zip;
	}
	
	
	
	
}

